import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import { v4 as uuid } from 'uuid';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '../..');
const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(root, 'client')));

const PORT = Number(process.env.PORT || 3000);

// SPA fallback: keeps the Veyra site working on browser refresh/deep links.

const PUBLIC_URL = (process.env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const COOKIE_NAME = 'veyra_session';
const dbPath = path.join(root, 'server', 'data.json');

type User = {
  id: string;
  username: string;
  email: string;
  password?: string;
  providers: string[];
  level: number;
  xp: number;
  coins: number;
  inventory: string[];
  equipped: Record<string, string>;
  createdAt: string;
  lastMatch?: string;
};

type Session = { userId: string; createdAt: number };
const users = new Map<string, User>();
const sessions = new Map<string, Session>();
const oauthStates = new Map<string, { provider: 'google' | 'microsoft'; createdAt: number; next: string }>();
const queues = new Set<string>();
const sockets = new Map<string, WebSocket>();
const matches = new Map<string, any>();

const cosmetics = [
  { id: 'hero_slate', name: 'Slate Vanguard', type: 'outfit' },
  { id: 'neon_pick', name: 'Neon Splitter', type: 'pickaxe' },
  { id: 'sky_pack', name: 'Skyline Pack', type: 'backbling' },
  { id: 'ember_wrap', name: 'Ember Circuit', type: 'wrap' }
];

function loadDb() {
  try {
    if (!fs.existsSync(dbPath)) return;
    const raw = JSON.parse(fs.readFileSync(dbPath, 'utf8')) as User[];
    for (const u of raw) users.set(u.id, u);
  } catch (e) {
    console.error('Could not load data.json:', e);
  }
}
function saveDb() {
  const tmp = `${dbPath}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify([...users.values()], null, 2));
  fs.renameSync(tmp, dbPath);
}
loadDb();

function safeUser(u: User) {
  return { id: u.id, username: u.username, email: u.email, level: u.level, xp: u.xp, coins: u.coins, inventory: u.inventory, equipped: u.equipped, providers: u.providers };
}
function makeSession(userId: string) {
  const t = uuid();
  sessions.set(t, { userId, createdAt: Date.now() });
  return t;
}
function getSessionToken(req: express.Request) {
  const bearer = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (bearer) return bearer;
  const raw = String(req.headers.cookie || '');
  const part = raw.split(';').map((x: string) => x.trim()).find((x: string) => x.startsWith(COOKIE_NAME + '='));
  return part ? decodeURIComponent(part.slice(COOKIE_NAME.length + 1)) : '';
}
function auth(req: any, res: any, next: any) {
  const t = getSessionToken(req);
  const session = sessions.get(t);
  const u = session ? users.get(session.userId) : undefined;
  if (!u) return res.status(401).json({ error: 'Unauthorized' });
  req.user = u;
  req.sessionToken = t;
  next();
}
function setSessionCookie(res: express.Response, token: string) {
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax${PUBLIC_URL.startsWith('https://') ? '; Secure' : ''}`);
}
function cleanUsername(input: string) {
  return input.trim().replace(/\s+/g, ' ').slice(0, 20);
}
function usernameFromEmail(email: string) {
  const base = (email.split('@')[0] || 'Player').replace(/[^a-zA-Z0-9_]/g, '').slice(0, 14) || 'Player';
  let name = base;
  let i = 1;
  const taken = new Set([...users.values()].map(u => u.username.toLowerCase()));
  while (taken.has(name.toLowerCase())) name = `${base}${i++}`;
  return name;
}
function makeUser({ username, email, password, provider }: { username?: string; email: string; password?: string; provider: string }) {
  const u: User = {
    id: uuid(),
    username: cleanUsername(username || usernameFromEmail(email)),
    email: email.trim().toLowerCase(),
    password,
    providers: [provider],
    level: 1,
    xp: 0,
    coins: 1200,
    inventory: ['hero_slate', 'neon_pick'],
    equipped: { outfit: 'hero_slate', pickaxe: 'neon_pick' },
    createdAt: new Date().toISOString()
  };
  users.set(u.id, u);
  saveDb();
  return u;
}
function issueLogin(res: express.Response, user: User, status = 200) {
  const token = makeSession(user.id);
  setSessionCookie(res, token);
  res.status(status).json({ token, user: safeUser(user), catalog: cosmetics });
}

// Email/password register + login.
app.post('/api/register', async (req, res) => {
  const username = cleanUsername(String(req.body.username || ''));
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (username.length < 3 || username.length > 20) return res.status(400).json({ error: 'Username must be 3-20 characters.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  if ([...users.values()].some(u => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: 'Username is already taken.' });
  if ([...users.values()].some(u => u.email === email)) return res.status(409).json({ error: 'An account already uses this email. Log in instead.' });
  const user = makeUser({ username, email, password: await bcrypt.hash(password, 12), provider: 'email' });
  issueLogin(res, user, 201);
});

app.post('/api/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = [...users.values()].find(u => u.email === email);
  if (!user || !user.password || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ error: 'Incorrect email or password.' });
  issueLogin(res, user);
});

app.post('/api/logout', auth, (req, res) => {
  sessions.delete(req.sessionToken);
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax`);
  res.json({ ok: true });
});
app.get('/api/session', auth, (req, res) => res.json({ token: req.sessionToken, user: safeUser(req.user), catalog: cosmetics }));
app.get('/api/me', auth, (req, res) => res.json({ user: safeUser(req.user), catalog: cosmetics }));
app.post('/api/equip', auth, (req, res) => {
  const { id } = req.body;
  const item = cosmetics.find(x => x.id === id);
  if (!item || !req.user.inventory.includes(id)) return res.status(400).json({ error: 'Item unavailable.' });
  req.user.equipped[item.type] = id;
  saveDb();
  res.json({ user: safeUser(req.user) });
});

function oauthConfigured(provider: 'google' | 'microsoft') {
  if (provider === 'google') return Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
  return Boolean(process.env.MICROSOFT_CLIENT_ID && process.env.MICROSOFT_CLIENT_SECRET);
}

function oauthState(provider: 'google' | 'microsoft', next = '/') {
  const state = crypto.randomBytes(24).toString('hex');
  oauthStates.set(state, { provider, createdAt: Date.now(), next: next.startsWith('/') ? next : '/' });
  setTimeout(() => oauthStates.delete(state), 10 * 60 * 1000);
  return state;
}

app.get('/auth/:provider', (req, res) => {
  const provider = req.params.provider as 'google' | 'microsoft';
  if (provider !== 'google' && provider !== 'microsoft') return res.status(404).send('Unknown provider');
  if (!oauthConfigured(provider)) {
    return res.status(503).send(`<h1>Veyra ${provider === 'google' ? 'Google' : 'Outlook'} sign-in is not configured</h1><p>Add the provider credentials to server/.env, then restart Veyra.</p>`);
  }
  const state = oauthState(provider);
  const redirectUri = `${PUBLIC_URL}/auth/${provider}/callback`;
  const url = new URL(provider === 'google' ? 'https://accounts.google.com/o/oauth2/v2/auth' : 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize');
  url.searchParams.set('client_id', provider === 'google' ? process.env.GOOGLE_CLIENT_ID! : process.env.MICROSOFT_CLIENT_ID!);
  url.searchParams.set('redirect_uri', redirectUri);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('state', state);
  url.searchParams.set('scope', provider === 'google' ? 'openid email profile' : 'openid profile email');
  url.searchParams.set('prompt', 'select_account');
  res.redirect(url.toString());
});

async function exchangeCode(provider: 'google' | 'microsoft', code: string, redirectUri: string) {
  const isGoogle = provider === 'google';
  const tokenUrl = isGoogle ? 'https://oauth2.googleapis.com/token' : 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
  const body = new URLSearchParams({
    client_id: isGoogle ? process.env.GOOGLE_CLIENT_ID! : process.env.MICROSOFT_CLIENT_ID!,
    client_secret: isGoogle ? process.env.GOOGLE_CLIENT_SECRET! : process.env.MICROSOFT_CLIENT_SECRET!,
    code,
    redirect_uri: redirectUri,
    grant_type: 'authorization_code'
  });
  const r = await fetch(tokenUrl, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body });
  if (!r.ok) throw new Error(`Token exchange failed (${r.status})`);
  return await r.json() as { access_token?: string };
}

async function providerProfile(provider: 'google' | 'microsoft', accessToken: string) {
  const url = provider === 'google' ? 'https://openidconnect.googleapis.com/v1/userinfo' : 'https://graph.microsoft.com/oidc/userinfo';
  const r = await fetch(url, { headers: { authorization: `Bearer ${accessToken}` } });
  if (!r.ok) throw new Error(`Profile request failed (${r.status})`);
  const p = await r.json() as any;
  return { email: String(p.email || '').trim().toLowerCase(), name: String(p.name || '').trim() };
}

async function oauthCallback(provider: 'google' | 'microsoft', req: express.Request, res: express.Response) {
  const state = String(req.query.state || '');
  const entry = oauthStates.get(state);
  oauthStates.delete(state);
  if (!entry || entry.provider !== provider || Date.now() - entry.createdAt > 10 * 60 * 1000) return res.status(400).send('Veyra sign-in session expired. Go back and try again.');
  const code = String(req.query.code || '');
  if (!code) return res.status(400).send(`Veyra could not complete ${provider} sign-in.`);
  try {
    const tokenData = await exchangeCode(provider, code, `${PUBLIC_URL}/auth/${provider}/callback`);
    if (!tokenData.access_token) throw new Error('No access token returned');
    const profile = await providerProfile(provider, tokenData.access_token);
    if (!profile.email) throw new Error('Provider did not return an email address');
    let user = [...users.values()].find(u => u.email === profile.email);
    if (!user) user = makeUser({ email: profile.email, username: profile.name || undefined, provider });
    else if (!user.providers.includes(provider)) { user.providers.push(provider); saveDb(); }
    const session = makeSession(user.id);
    setSessionCookie(res, session);
    res.redirect('/?oauth=success');
  } catch (e: any) {
    console.error(`${provider} OAuth error:`, e);
    res.status(500).send(`<h1>Veyra sign-in failed</h1><p>${String(e?.message || 'Unknown error')}</p><p><a href="/">Return to Veyra</a></p>`);
  }
}
app.get('/auth/google/callback', (req, res) => oauthCallback('google', req, res));
app.get('/auth/microsoft/callback', (req, res) => oauthCallback('microsoft', req, res));

app.get('*', (req, res, next) => { if (req.path.startsWith('/api/') || req.path.startsWith('/auth/')) return next(); res.sendFile(path.join(root, 'client', 'index.html')); });

// Lightweight prototype game server.
function broadcast(match: any, msg: any) { for (const id of match.players) { const ws = sockets.get(id); if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg)); } }
function newMatch() { const id = uuid(); const m = { id, players: [], started: false, startAt: Date.now() + 5000, world: { w: 2400, h: 1400 }, storm: { x: 1200, y: 700, r: 620, nextR: 450, phase: 0 }, entities: new Map(), builds: new Map() }; matches.set(id, m); return m; }
function makePlayer(id: string) { return { id, x: 250 + Math.random() * 1900, y: 150 + Math.random() * 1100, hp: 100, shield: 50, ammo: 30, weapon: 'pulse', alive: true, score: 0 }; }
function joinQueue(id: string) { queues.add(id); setTimeout(() => { if (!queues.has(id)) return; queues.delete(id); const m = newMatch(); m.players.push(id); const p = makePlayer(id); m.entities.set(id, p); const u = users.get(id)!; u.lastMatch = m.id; u.xp += 20; u.level = 1 + Math.floor(u.xp / 100); saveDb(); sockets.get(id)?.send(JSON.stringify({ type: 'matchFound', matchId: m.id, player: p, world: m.world })); }, 500); }
function serializeMatch(mt: any, viewer: string) { return { id: mt.id, world: mt.world, storm: mt.storm, players: [...mt.entities.values()].map((p: any) => ({ ...p, self: p.id === viewer })), builds: [...mt.builds.values()] }; }

const server = app.listen(PORT, () => console.log(`Veyra running at ${PUBLIC_URL}`));
const wss = new WebSocketServer({ server });
wss.on('connection', ws => {
  let userId = ''; let matchId = '';
  ws.on('message', raw => {
    try {
      const m = JSON.parse(String(raw));
      if (m.type === 'auth') { userId = sessions.get(m.token)?.userId || ''; if (userId) sockets.set(userId, ws); ws.send(JSON.stringify({ type: 'auth', ok: !!userId })); return; }
      if (!userId) return;
      if (m.type === 'queue') joinQueue(userId);
      else if (m.type === 'joinMatch') { matchId = m.matchId; const mt = matches.get(matchId); if (!mt) return; if (!mt.players.includes(userId)) mt.players.push(userId); if (!mt.entities.has(userId)) mt.entities.set(userId, makePlayer(userId)); mt.started = true; broadcast(mt, { type: 'state', state: serializeMatch(mt, userId) }); }
      else if (m.type === 'input') { const mt = matches.get(matchId); const p = mt?.entities.get(userId); if (!p || !p.alive) return; const dt = Math.min(0.05, Math.max(0, Number(m.dt) || 0.016)); const s = 220; p.x = Math.max(30, Math.min(mt.world.w - 30, p.x + (m.dx || 0) * s * dt)); p.y = Math.max(30, Math.min(mt.world.h - 30, p.y + (m.dy || 0) * s * dt)); }
      else if (m.type === 'shoot') { const mt = matches.get(matchId); const p = mt?.entities.get(userId); if (p?.ammo > 0) { p.ammo--; p.score++; } }
      else if (m.type === 'build') { const mt = matches.get(matchId); const p = mt?.entities.get(userId); if (p) { const key = uuid(); mt.builds.set(key, { x: p.x + (m.ox || 0), y: p.y + (m.oy || 0), rot: m.rot || 0 }); } }
    } catch { }
  });
  ws.on('close', () => { if (userId) sockets.delete(userId); });
});
setInterval(() => {
  for (const mt of matches.values()) {
    if (!mt.started) continue;
    if (Date.now() > mt.startAt + 30000 && mt.storm.r > 170) mt.storm.r -= 2;
    for (const p of mt.entities.values()) { const d = Math.hypot(p.x - mt.storm.x, p.y - mt.storm.y); if (d > mt.storm.r) { p.hp -= 0.15; if (p.hp <= 0) p.alive = false; } }
    broadcast(mt, { type: 'state', state: serializeMatch(mt, '') });
  }
}, 1000 / 10);
