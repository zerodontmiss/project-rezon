PROJECT REZON - ONE CLICK ORIGINAL PROTOTYPE

This is an original private battle-royale-style prototype.
It does not include Fortnite/Epic client files or anti-cheat bypasses.

RUN:
1. Extract the whole folder.
2. Double-click the launcher executable in the folder (see your previous launcher build), or run the server manually with:
   cd server
   npm install
   npm start
3. Open http://localhost:3000

AUTH:
- Email/password registration and login work locally.
- Google and Microsoft/Outlook require your own OAuth app credentials in server/.env.

EDIT WEBSITE:
- client/index.html = layout, text, title, branding, styles
- client/app.js = login, account creation, buttons, lobby, matchmaking, gameplay UI
