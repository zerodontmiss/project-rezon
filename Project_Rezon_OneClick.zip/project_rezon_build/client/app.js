(() => {
  "use strict";

  const $ = id => document.getElementById(id);
  const els = {
    auth: $("auth"), lobby: $("lobby"), game: $("game"), hud: $("hud"),
    authForm: $("authForm"), loginTab: $("loginTab"), createTab: $("createTab"),
    usernameField: $("usernameField"), username: $("username"), email: $("email"),
    password: $("password"), submitBtn: $("submitBtn"), msg: $("msg"),
    googleBtn: $("googleBtn"), microsoftBtn: $("microsoftBtn"), logoutBtn: $("logoutBtn"),
    playBtn: $("playBtn"), lockerBtn: $("lockerBtn"), locker: $("locker"), items: $("items"),
    profile: $("profile"), hp: $("hp"), ammo: $("ammo"), storm: $("storm"), toast: $("toast")
  };

  const ctx = els.game.getContext("2d");
  const storageKey = "project_rezon_token";
  let mode = "login";
  let token = localStorage.getItem(storageKey) || "";
  let me = null;
  let catalog = [];
  let ws = null;
  let state = null;
  let socketReady = false;
  let keys = Object.create(null);
  let shooting = false;
  let mouse = { x: 0, y: 0 };
  let lastFrame = performance.now();

  function setMessage(text = "", error = true) {
    els.msg.textContent = text;
    els.msg.style.color = error ? "#ff8b9a" : "#7df2ad";
  }

  function toast(text) {
    els.toast.textContent = text;
    els.toast.classList.remove("hidden");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => els.toast.classList.add("hidden"), 2200);
  }

  function setMode(next) {
    mode = next;
    const creating = mode === "create";
    els.loginTab.classList.toggle("active", !creating);
    els.createTab.classList.toggle("active", creating);
    els.usernameField.classList.toggle("hidden", !creating);
    els.submitBtn.textContent = creating ? "Create account" : "Log in";
    els.password.autocomplete = creating ? "new-password" : "current-password";
    setMessage("");
  }

  async function api(path, options = {}) {
    const headers = { ...(options.headers || {}) };
    if (token) headers.Authorization = `Bearer ${token}`;
    const response = await fetch(path, { credentials: "include", ...options, headers });
    let data = {};
    try { data = await response.json(); } catch {}
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
    return data;
  }

  async function submitAuth(event) {
    event.preventDefault();
    setMessage("Signing you in...", false);
    els.submitBtn.disabled = true;

    try {
      const body = {
        email: els.email.value.trim(),
        password: els.password.value
      };
      if (mode === "create") body.username = els.username.value.trim();

      const data = await api(mode === "create" ? "/api/register" : "/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });

      token = data.token;
      localStorage.setItem(storageKey, token);
      me = data.user;
      catalog = data.catalog || [];
      setMessage("");
      showLobby();
      toast(mode === "create" ? "Account created." : "Welcome back.");
    } catch (error) {
      setMessage(error.message);
    } finally {
      els.submitBtn.disabled = false;
    }
  }

  function oauth(provider) {
    window.location.href = `/auth/${provider}`;
  }

  async function restoreSession() {
    if (!token) return false;
    try {
      const data = await api("/api/session");
      me = data.user;
      catalog = data.catalog || [];
      showLobby();
      return true;
    } catch {
      token = "";
      localStorage.removeItem(storageKey);
      return false;
    }
  }

  function showLobby() {
    els.auth.classList.add("hidden");
    els.game.classList.add("hidden");
    els.hud.classList.add("hidden");
    els.lobby.classList.remove("hidden");
    els.profile.textContent = `${me.username} · Level ${me.level} · ${me.xp} XP · ${me.coins} credits`;
    renderLocker();
  }

  function renderLocker() {
    els.items.innerHTML = "";
    for (const item of catalog) {
      const owned = me?.inventory?.includes(item.id);
      const row = document.createElement("div");
      row.className = "item";
      row.innerHTML = `<div><strong>${item.name}</strong><small>${item.type}</small></div>`;
      const button = document.createElement("button");
      button.className = "secondary";
      button.textContent = owned ? "Equip" : "Locked";
      button.disabled = !owned;
      button.addEventListener("click", () => equip(item.id));
      row.appendChild(button);
      els.items.appendChild(row);
    }
  }

  async function equip(id) {
    try {
      const data = await api("/api/equip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      me = data.user;
      renderLocker();
      toast("Item equipped.");
    } catch (error) {
      toast(error.message);
    }
  }

  function connect() {
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
    const protocol = location.protocol === "https:" ? "wss" : "ws";
    ws = new WebSocket(`${protocol}://${location.host}`);
    socketReady = false;

    ws.addEventListener("open", () => {
      socketReady = true;
      ws.send(JSON.stringify({ type: "auth", token }));
      ws.send(JSON.stringify({ type: "queue" }));
    });

    ws.addEventListener("message", event => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === "auth" && !message.ok) {
          toast("Session expired. Please log in again.");
          logout();
        }
        if (message.type === "matchFound") {
          ws.send(JSON.stringify({ type: "joinMatch", matchId: message.matchId }));
          startGame();
        }
        if (message.type === "state") state = message.state;
      } catch {}
    });

    ws.addEventListener("close", () => { socketReady = false; });
  }

  function queue() {
    if (!token) return;
    connect();
    toast("Searching for a match...");
  }

  function startGame() {
    els.lobby.classList.add("hidden");
    els.game.classList.remove("hidden");
    els.hud.classList.remove("hidden");
    resizeCanvas();
  }

  async function logout() {
    try { if (token) await api("/api/logout", { method: "POST" }); } catch {}
    token = ""; me = null; catalog = []; state = null;
    localStorage.removeItem(storageKey);
    if (ws) ws.close();
    ws = null;
    els.lobby.classList.add("hidden");
    els.game.classList.add("hidden");
    els.hud.classList.add("hidden");
    els.auth.classList.remove("hidden");
    els.authForm.reset();
    setMode("login");
  }

  function resizeCanvas() {
    const dpr = Math.max(1, Math.min(2, devicePixelRatio || 1));
    els.game.width = innerWidth * dpr;
    els.game.height = innerHeight * dpr;
    els.game.style.width = `${innerWidth}px`;
    els.game.style.height = `${innerHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function send(type, payload = {}) {
    if (socketReady && ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type, ...payload }));
  }

  function gameLoop(time) {
    const dt = Math.min(0.033, (time - lastFrame) / 1000);
    lastFrame = time;
    if (!els.game.classList.contains("hidden") && state) {
      let dx = (keys.d ? 1 : 0) - (keys.a ? 1 : 0);
      let dy = (keys.s ? 1 : 0) - (keys.w ? 1 : 0);
      if (dx || dy) { const len = Math.hypot(dx, dy); dx /= len; dy /= len; }
      send("input", { dx, dy, dt });
      if (shooting) send("shoot");
      draw();
    }
    requestAnimationFrame(gameLoop);
  }

  function draw() {
    ctx.clearRect(0, 0, innerWidth, innerHeight);
    const self = state.players.find(p => p.self) || state.players[0];
    if (!self) return;
    const scale = Math.min(innerWidth / state.world.width, innerHeight / state.world.height) * 0.9;
    const ox = (innerWidth - state.world.width * scale) / 2;
    const oy = (innerHeight - state.world.height * scale) / 2;
    ctx.save(); ctx.translate(ox, oy); ctx.scale(scale, scale);
    ctx.fillStyle = "#17233a"; ctx.fillRect(0, 0, state.world.width, state.world.height);
    ctx.strokeStyle = "#20304a"; ctx.lineWidth = 1 / scale;
    for (let x = 0; x < state.world.width; x += 120) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, state.world.height); ctx.stroke(); }
    for (let y = 0; y < state.world.height; y += 120) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(state.world.width, y); ctx.stroke(); }
    ctx.beginPath(); ctx.arc(state.storm.x, state.storm.y, state.storm.r, 0, Math.PI * 2); ctx.strokeStyle = "#8a7cff"; ctx.lineWidth = 8 / scale; ctx.stroke();
    for (const build of state.builds) { ctx.save(); ctx.translate(build.x, build.y); ctx.rotate(build.rotation || 0); ctx.fillStyle = "#8a6b4a"; ctx.fillRect(-22, -22, 44, 44); ctx.restore(); }
    for (const player of state.players) {
      if (!player.alive) continue;
      ctx.beginPath(); ctx.arc(player.x, player.y, 20, 0, Math.PI * 2); ctx.fillStyle = player.self ? "#53e0ff" : "#ff6b7d"; ctx.fill();
      ctx.fillStyle = "#111"; ctx.fillRect(player.x - 22, player.y - 34, 44, 5);
      ctx.fillStyle = "#63ff88"; ctx.fillRect(player.x - 22, player.y - 34, 44 * Math.max(0, player.hp) / 100, 5);
    }
    ctx.restore();
    els.hp.textContent = `HP ${Math.max(0, Math.round(self.hp))}`;
    els.ammo.textContent = `AMMO ${self.ammo}`;
    els.storm.textContent = `STORM ${Math.round(state.storm.r)}`;
  }

  els.loginTab.addEventListener("click", () => setMode("login"));
  els.createTab.addEventListener("click", () => setMode("create"));
  els.authForm.addEventListener("submit", submitAuth);
  els.googleBtn.addEventListener("click", () => oauth("google"));
  els.microsoftBtn.addEventListener("click", () => oauth("microsoft"));
  els.logoutBtn.addEventListener("click", logout);
  els.playBtn.addEventListener("click", queue);
  els.lockerBtn.addEventListener("click", () => els.locker.classList.toggle("hidden"));
  addEventListener("resize", resizeCanvas);
  addEventListener("keydown", event => { keys[event.key.toLowerCase()] = true; if (event.key.toLowerCase() === "b") send("build", { ox: 50, oy: 0 }); });
  addEventListener("keyup", event => { keys[event.key.toLowerCase()] = false; });
  els.game.addEventListener("mousemove", event => { mouse.x = event.clientX; mouse.y = event.clientY; });
  els.game.addEventListener("mousedown", event => { if (event.button === 0) shooting = true; });
  addEventListener("mouseup", () => { shooting = false; });

  // OAuth returns here as /?oauth=success. The session cookie is already set by the server.
  if (new URLSearchParams(location.search).get("oauth") === "success") {
    history.replaceState({}, "", "/");
    toast("Signed in successfully.");
  }

  setMode("login");
  restoreSession();
  requestAnimationFrame(gameLoop);
})();
